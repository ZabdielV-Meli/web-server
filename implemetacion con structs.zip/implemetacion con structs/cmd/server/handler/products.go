package handlers

import (
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
	internal "github.com/zabdielv/gin-exercises/internal/products"
)

// constructor
func NewControllerProduct(sv *internal.ServiceProduct) *ControllerProduct {
	return &ControllerProduct{sv: sv}
}

// controller
type ControllerProduct struct {
	sv *internal.ServiceProduct
}

// Obtener productos
func (ct *ControllerProduct) ObtenerProductos() gin.HandlerFunc {

	return func(c *gin.Context) {
		ct.sv.ObtenerDB()
	}

}

// Filtrar por precio
func (ct *ControllerProduct) FiltrarPorId() gin.HandlerFunc {

	return func(c *gin.Context) {
		//castear de string a int
		priceGt, _ := strconv.ParseFloat(c.Query("priceGt"), 64)

		sliceQuery := ct.sv.FiltrarSlice(priceGt)
		c.JSON(200, sliceQuery)
	}

}

// Buscar por ID
func (ct *ControllerProduct) BuscarProducto() gin.HandlerFunc {

	return func(c *gin.Context) {

		//castear de string a int
		id, _ := strconv.Atoi(c.Param("id"))

		//Buscar por id
		producto, err := ct.sv.BuscarProducto(id)
		if err != nil {
			c.JSON(404, gin.H{
				"message": err.Error(),
			})
		} else {
			c.JSON(200, producto)
		}
	}

}

func (ct *ControllerProduct) Guardar() gin.HandlerFunc {
	type request struct {
		Name         string  `json:"name"`
		Quantity     int     `json:"quantity"`
		Code_value   int     `json:"code_value" `
		Is_published bool    `json:"is_published"`
		Expiration   string  `json:"expiration" `
		Price        float64 `json:"price"`
	}
	return func(ctx *gin.Context) {

		var req request
		if err := ctx.ShouldBindJSON(&req); err != nil {
			ctx.JSON(404, gin.H{
				"error": "parametros no validos",
			})
			fmt.Println(err)
			return
		}

		newProduct, err := ct.sv.Guardar(req.Name, req.Quantity, req.Code_value, req.Is_published, req.Expiration, req.Price)

		if err != nil {
			ctx.JSON(200, gin.H{
				"error": err,
			})
			return
		}

		ctx.JSON(200, gin.H{
			"ok":       "producto añadido correctamente",
			"producto": newProduct,
		})
	}
}

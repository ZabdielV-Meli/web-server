package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"

	"github.com/gin-gonic/gin"

	handlers "github.com/zabdielv/gin-exercises/cmd/server/handler"
	domain "github.com/zabdielv/gin-exercises/internal/domain"
	internal "github.com/zabdielv/gin-exercises/internal/products"
)

// Inicializa los productos a un slice
func getData(sliceProdcuctos *[]domain.Producto) {
	//leer el archivo JSON
	arrayBites, err := os.ReadFile("../products.json")

	if err != nil {
		fmt.Println("el archivo indicado no fue encontrado")
		return
	} else {
		if err2 := json.Unmarshal(arrayBites, sliceProdcuctos); err != nil {
			log.Fatal(err2)
			return
		}
	}

}

func main() {

	// Crea un router con gin
	router := gin.Default()

	// Slice de productos
	var db []domain.Producto

	//Get data from JSON file
	getData(&db)

	sv := internal.NewServiceProductoLocal(&db, len(db))
	ct := handlers.NewControllerProduct(sv)
	//Ruta /ping
	router.GET("/ping", func(c *gin.Context) {
		c.String(200, "pong")
	})

	//Ruta /products
	router.GET("/products", ct.ObtenerProductos())

	//Ruta /products/:id
	router.GET("/products/:id", ct.BuscarProducto())

	pr := router.Group("/products")

	//Ruta /products/search
	pr.GET("/", ct.FiltrarPorId())
	//Guardar producto
	pr.POST("/", ct.Guardar())

	// Corremos nuestro servidor sobre el puerto 8080
	router.Run()
	fmt.Println("Servidor corriendo")
}

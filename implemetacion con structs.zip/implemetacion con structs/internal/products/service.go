package internal

import (
	"errors"
	"regexp"

	internal "github.com/zabdielv/gin-exercises/internal/domain"
)

var (
	ErrMovieNotFound       = errors.New("movie not found")
	ErrMovieErrorArguments = errors.New("invalid or nul arguments")
)

// controller
func NewServiceProductoLocal(db *[]internal.Producto, lastID int) *ServiceProduct {
	return &ServiceProduct{
		db:     db,
		lastID: lastID,
	}
}

type ServiceProduct struct {
	db     *[]internal.Producto
	lastID int
}

func buscarPorId(id int, sliceProdcuctos []internal.Producto) (internal.Producto, error) {

	for _, valor := range sliceProdcuctos {
		if valor.ID == id {
			return valor, nil
		}
	}

	return internal.Producto{}, errors.New("ID no encontrado")
}

// Obtener DB
func (sv *ServiceProduct) ObtenerDB() (producto []internal.Producto) {

	return *sv.db
}

// Filtrar por precio
func (sv *ServiceProduct) FiltrarSlice(priceGt float64) (producto []internal.Producto) {

	sliceQuery := []internal.Producto{}

	for _, valor := range *sv.db {
		if valor.Price > priceGt {
			sliceQuery = append(sliceQuery, valor)
		}
	}

	return sliceQuery
}

func (sv *ServiceProduct) BuscarProducto(id int) (producto internal.Producto, err error) {

	//Buscar por id
	producto, err = buscarPorId(id, *sv.db)

	if err != nil {
		err = ErrMovieNotFound
		return
	}

	return producto, nil

}

func (sv *ServiceProduct) Guardar(name string, quantity int, code_value int, Is_published bool, expiration string, price float64) (producto internal.Producto, err error) {

	//parametros vacios
	if name == "" || price == 0.0 || code_value == 0 || quantity == 0 || price == 0 || expiration == "" {
		return internal.Producto{}, ErrMovieErrorArguments
	}

	//Code value unico
	for _, valor := range *sv.db {
		if code_value == valor.Code_value {
			return internal.Producto{}, ErrMovieErrorArguments
		}
	}

	//validar fecha
	re := regexp.MustCompile("^[0-3]?[0-9][/][0-3]?[0-9][/]([0-9]{2})?[0-9]{2}$")
	//_, err := time.Parse("01/02/2006", req.Expiration)
	if !re.MatchString(expiration) {
		return internal.Producto{}, ErrMovieErrorArguments
	}

	producto = internal.Producto{
		ID:           sv.lastID + 1,
		Name:         name,
		Quantity:     quantity,
		Code_value:   code_value,
		Is_published: Is_published,
		Expiration:   expiration,
		Price:        price,
	}

	// save
	*sv.db = append(*sv.db, producto)
	sv.lastID++

	return producto, nil
}
